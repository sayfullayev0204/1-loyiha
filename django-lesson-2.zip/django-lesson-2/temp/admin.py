from django.contrib import admin
from .models import Car, About
# Register your models here.
a = [Car, About]
for i in a:
    admin.site.register(i)
