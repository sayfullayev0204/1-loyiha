from django.db import models
from django.urls import reverse


# Create your models here.
class Car(models.Model):
    name = models.CharField(max_length=255)
    color = models.CharField(max_length=255)
    info = models.TextField()
    year = models.IntegerField()
    factory = models.CharField(max_length=255)
    image = models.ImageField(upload_to='cars/', null=True, blank=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('car-info', args=[str(self.pk)])


class About(models.Model):
    title = models.CharField(max_length=155)
    img = models.ImageField(upload_to='about/')
    info = models.TextField()

    def __str__(self):
        return self.title

