from django.urls import path
from .views import (
    CarView,
    CarInfoView,
    AboutView,
    AllCars,
    CarUpdateView,
    CarDeleteView,
    CarCreateView
)

urlpatterns = [
    path('cars/', CarView.as_view(), name='cars-list'),
    path('add-car/', CarCreateView.as_view(), name='add-car'),
    path('all-cars/', AllCars.as_view(), name='all-cars'),
    path('about/', AboutView.as_view(), name='about'),
    path('car/<int:pk>/', CarInfoView.as_view(), name='car-info'),
    path('car/delete/<int:pk>/', CarDeleteView.as_view(), name='car-delete'),
    path('car-update/<int:pk>/', CarUpdateView.as_view(), name='car-update')
]