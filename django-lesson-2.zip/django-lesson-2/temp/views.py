from django.shortcuts import render
from django.views.generic import (
    TemplateView,
    ListView,
    UpdateView,
    DeleteView,
    CreateView
)
from .models import Car, About
from django.urls import reverse_lazy
from .forms import CarForm


class CarView(TemplateView):
    def get(self, request):
        context = {}
        clay = Car.objects.all()
        context['data'] = clay
        return render(request, 'main/car.html', context)


class CarInfoView(TemplateView):
    def get(self, request, pk):
        context = {}
        context['clay'] = Car.objects.filter(id=pk)
        return render(request, 'main/info-car.html', context)


class AboutView(ListView):
    def get(self, request):
        context = {}
        none = About.objects.all()
        context['about'] = none
        return render(request, 'main/about.html', context)


class AllCars(ListView):
    model = Car
    template_name = 'all-cars.html'
    context_object_name = 'cars'


class CarUpdateView(UpdateView):
    model = Car
    template_name = 'car/car-edit.html'
    form_class = CarForm


class CarDeleteView(DeleteView):
    model = Car
    template_name = 'car/car-delete.html'
    success_url = reverse_lazy('all-cars')


class CarCreateView(CreateView):
    model = Car
    template_name = 'car/new-car.html'
    fields = ['name', 'color', 'info', 'year', 'factory', 'image']
    success_url = reverse_lazy('all-cars')